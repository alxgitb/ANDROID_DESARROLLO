package com.abx.puppy;

import java.util.ArrayList;

interface Inicializadores {

    void initBar();
    void inicLista();
    void initRecyclerV();


}
