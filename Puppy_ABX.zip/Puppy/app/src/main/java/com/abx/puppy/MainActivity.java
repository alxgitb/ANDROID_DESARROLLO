package com.abx.puppy;

import android.content.Intent;
import android.graphics.Color;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.support.v7.widget.SearchView;
import android.view.View;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity implements Inicializadores {
    static ArrayList<Puppy> list;
    private RecyclerView lp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Take a Picture To Your Pet!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        initBar();
        initRecyclerV();
        inicLista();


    }

    @Override
    public void initRecyclerV() {
        lp = findViewById(R.id.recyclerv);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        lp.setLayoutManager(llm);

    }

    @Override
    public void initBar() {
        Toolbar myToolbar = findViewById(R.id.appbar);
        myToolbar.setTitleTextColor(Color.WHITE);
        myToolbar.setTitle("Petagram");
        myToolbar.setLogo(R.drawable.icons8_cat_footprint_24);
        setSupportActionBar(myToolbar);
    }



    public void inicAdaptador(ArrayList<Puppy> l ) {
            PuppyAdapter adaptador = new PuppyAdapter(l);
            lp.setAdapter(adaptador);
    }

    @Override
    public void inicLista() {
        list = new ArrayList<Puppy>();
        list.add(new Puppy("MASCOTA1", R.drawable.p1));
        list.add(new Puppy("MASCOTA2", R.drawable.p2));
        list.add(new Puppy("MASCOTA3", R.drawable.p3));
        list.add(new Puppy("MASCOTA4", R.drawable.p4));
        list.add(new Puppy("MASCOTA5", R.drawable.p5));
        list.add(new Puppy("MASCOTA6", R.drawable.p6));
        list.add(new Puppy("MASCOTA7", R.drawable.p7));
        list.add(new Puppy("MASCOTA8", R.drawable.p8));
        list.add(new Puppy("MASCOTA9", R.drawable.p9));
        inicAdaptador(list);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.items_actionbar, menu);
        MenuItem searchItem = menu.findItem(R.id.action_seach);
        SearchView sw = (SearchView) searchItem.getActionView();
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.five_liked:
                Intent i = new Intent(this, PuppyList.class);
                i.putExtra("top", true);
                startActivityForResult(i, 1);

            case R.id.action_settings:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
