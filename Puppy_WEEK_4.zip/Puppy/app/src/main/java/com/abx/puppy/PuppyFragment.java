package com.abx.puppy;


import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.Loader;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;




/**
 * A simple {@link Fragment} subclass.
 */
public class PuppyFragment extends Fragment {
    static RecyclerView lp2,lp3;
    static ArrayList<Puppy>lista = new ArrayList<Puppy>();



    public PuppyFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_puppy, container, false);
        FloatingActionButton fab = v.findViewById(R.id.fab2);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Take a Picture To Your Pet!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        lp2 = (RecyclerView) v.findViewById(R.id.recyclerv2);
        GridLayoutManager glm = new GridLayoutManager(getContext(),3);
        glm.setOrientation(LinearLayoutManager.VERTICAL);
        lp2.setLayoutManager(glm);
        lp3 = (RecyclerView) v.findViewById(R.id.recyclerv3);
        LinearLayoutManager llm = new LinearLayoutManager(getContext());
        llm.setOrientation(LinearLayoutManager.HORIZONTAL);
        lp3.setLayoutManager(llm);
        inicLista();


        return v;
    }

    public void inicLista() {
        ArrayList<Puppy>list = new ArrayList<Puppy>();
        list.add(new Puppy("MASCOTA1", R.drawable.p1,1));
        list.add(new Puppy("MASCOTA2", R.drawable.p2,1));
        list.add(new Puppy("MASCOTA3", R.drawable.p3,1));
        list.add(new Puppy("MASCOTA4", R.drawable.p4,1));
        list.add(new Puppy("MASCOTA5", R.drawable.p5,1));
        list.add(new Puppy("MASCOTA6", R.drawable.p6,1));
        list.add(new Puppy("MASCOTA7", R.drawable.p7,1));
        list.add(new Puppy("MASCOTA8", R.drawable.p8,1));
        list.add(new Puppy("MASCOTA9", R.drawable.p9,1));

        lista.add(0,new Puppy("MASCOTA1", R.drawable.p1,2));
        lista.add(1,new Puppy("MASCOTA2", R.drawable.p1,2));
        lista.add(2,new Puppy("MASCOTA3", R.drawable.p1,2));
        lista.add(3,new Puppy("MASCOTA4", R.drawable.p1,2));
        lista.add(4,new Puppy("MASCOTA5", R.drawable.p1,2));
        lista.add(5,new Puppy("MASCOTA6", R.drawable.p1,2));
        lista.add(6,new Puppy("MASCOTA7", R.drawable.p1,2));
        lista.add(7,new Puppy("MASCOTA8", R.drawable.p1,2));
        lista.add(8,new Puppy("MASCOTA9", R.drawable.p1,2));
        inicAdaptador(list);
    }



    public void inicAdaptador(ArrayList<Puppy> l) {
        AdapterImg adapt = new AdapterImg(l);
        lp3.setAdapter(adapt);
        adapt = new AdapterImg(lista);
        lp2.setAdapter(adapt);


    }





}
