package com.abx.puppy;


import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class Contacto extends AppCompatActivity {


    Context context = null;
    String N, COR, COM;
    EditText nom, correo, com;
    @SuppressLint("StaticFieldLeak")
    static Button btn_env;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_contacto);

        nom = findViewById(R.id.tieNombre);
        nom.setMovementMethod(new ScrollingMovementMethod());

        correo = findViewById(R.id.tieCorreo);
        correo.setMovementMethod(new ScrollingMovementMethod());

        com =  findViewById(R.id.tieCom);
        com.setMovementMethod(new ScrollingMovementMethod());
        context = this;

        initBar();

        btn_env = findViewById(R.id.btn_env);
        btn_env.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                N = nom.getText().toString();
                COR = correo.getText().toString();
                COM = com.getText().toString();
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {

                            /*
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            ******************************************************************
                            * */

                            String  user="";
                            String  pass="";
                            String  SENDER=user;
                            String  RECIPIENT=user;

                            /*
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             ******************************************************************
                             * */

                            Sender sender = new Sender(user,pass);
                            sender.sendMail("Hello from JavaMail",
                                                    COM,
                                                    SENDER,
                                                    RECIPIENT);
                        } catch (Exception e) {
                            Log.e("SendMail", e.getMessage(), e);
                        }
                    }

                }).start();


            }
        });


    }


    public void initBar() {
        Toolbar myToolbar = findViewById(R.id.appbar);
        //TextView t = myToolbar.findViewById(R.id.tv_titulo);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}

