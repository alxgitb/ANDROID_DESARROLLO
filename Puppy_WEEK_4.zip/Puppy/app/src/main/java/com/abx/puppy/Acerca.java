package com.abx.puppy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

  public class Acerca extends AppCompatActivity implements Inicializadores {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_acerca);
        TextView bio = (TextView) findViewById(R.id.txt_bio);
        bio.setMovementMethod(new ScrollingMovementMethod());
        initBar();

    }


    @Override
    public void initBar() {
        Toolbar myToolbar = findViewById(R.id.appbar);
        TextView t = myToolbar.findViewById(R.id.tv_titulo);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

      @Override
      public boolean onSupportNavigateUp(){
          finish();
          return true;
      }

     @Override
     public void inicLista() {

     }

     @Override
     public void initRecyclerV() {

     }

 }
