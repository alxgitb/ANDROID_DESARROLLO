package com.abx.puppy;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PuppyList extends AppCompatActivity implements Inicializadores {

    private RecyclerView lp2;
    static ArrayList<Puppy> list2 = new ArrayList<Puppy>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.puppy_list);
        initBar();
        initRecyclerV();
        inicLista();
    }
    @Override
    public void initBar() {
        Toolbar myToolbar = findViewById(R.id.appbar);
        TextView t= myToolbar.findViewById(R.id.tv_titulo);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


    }

    @Override
    public void inicLista() {

            Collections.sort(ListaFragment.list, new Comparator<Puppy>() {
                @Override
                public int compare(Puppy puppy, Puppy t1) {
                    return t1.getRate() - puppy.getRate();
                }
            });
            for (int x = 0; x < 5; x++)
                list2.add(new Puppy(ListaFragment.list.get(x).getNom(),
                        ListaFragment.list.get(x).getFoto(),
                        ListaFragment.list.get(x).getRate()));
            inicAdaptador(list2);
    }

    @Override
    public void initRecyclerV() {
        lp2 = findViewById(R.id.recyclerv2);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        lp2.setLayoutManager(llm);

    }


    public void inicAdaptador(ArrayList<Puppy> l) {
        PuppyAdapter adaptador = new PuppyAdapter(l);
        lp2.setAdapter(adaptador);
      }


    @Override
    public boolean onSupportNavigateUp(){
        list2.clear();
        finish();
        return true;
    }



}
