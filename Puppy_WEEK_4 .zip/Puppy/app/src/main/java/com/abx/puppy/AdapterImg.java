package com.abx.puppy;

import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdapterImg extends RecyclerView.Adapter<AdapterImg.PuppyViewHolder> {

    ArrayList<Puppy> mascotas_img;


    AdapterImg(ArrayList<Puppy> p) {
        this.mascotas_img = p;


    }

    @NonNull
    @Override //Crea las Lista de Elementos, se asocia al RecyclerView
    //Infla el layout y lo pasara al viewholder para que el obtenga los views
    public PuppyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView;

        switch (viewType) {

            case Puppy.TYPE_TWO:

                itemView = LayoutInflater.from(parent.getContext())

                        .inflate(R.layout.perfil_imagen, parent, false);

                PuppyViewHolder viewHolder = new PuppyViewHolder(itemView);

                return viewHolder;

            case Puppy.TYPE_THREE:

                itemView = LayoutInflater.from(parent.getContext())

                        .inflate(R.layout.perfil_mascotas, parent, false);

                PuppyViewHolder viewFoto = new PuppyViewHolder(itemView);

                return viewFoto;

        }

        return null;


    }

    @Override
    //Se envía las list de elementos, a cada elemento del constructor del ViewHolder declarado abajo, se setean las variables.
    //Asocia cada elemento de la list con cada view
    public void onBindViewHolder(@NonNull PuppyViewHolder holder, int position) {
        Puppy masc = mascotas_img.get(position);


        if (masc.getType() == Puppy.TYPE_TWO) {
            holder.img.setImageResource(masc.getFoto());
            holder.nomm.setText(masc.getNom());
            try{PuppyFragment.lista.clear();
                ArrayList<Puppy> m = new ArrayList<Puppy>();
                for (byte i = 0; i < 10; i++) {
                    //PuppyFragment.lista.remove(i);
                    //PuppyFragment.lista.set(i,new Puppy(masc.getNom(), masc.getFoto(), 2, 5));
                    //PuppyFragment.lp2.getAdapter().notifyItemRemoved(i);
                    //PuppyFragment.lp2.getAdapter().notifyItemRangeChanged(i, PuppyFragment.lista.size());
                    m.add(i, new Puppy(masc.getNom(), masc.getFoto(), 2, 5));
                }

                PuppyFragment.lista.addAll(m);
                PuppyFragment.lp2.getAdapter().notifyDataSetChanged();
                PuppyFragment.lp2.getAdapter().notify();
            }catch (Exception IndexOutOfBoundsException){

            }


        } else {

            holder.imag.setImageResource(masc.getFoto());
            holder.rate.setText(((Object) (masc.getRate())).toString());

        }


    }


    @Override //Cantidad de elementos de la Lista
    public int getItemCount() {
        return mascotas_img.size();
    }

    @Override

    public int getItemViewType(int position) {

        if (mascotas_img != null) {

            Puppy item = mascotas_img.get(position);

            if (item != null) {

                return item.getType();

            }

        }

        //fallback

        return 0;

    }




    public static class PuppyViewHolder extends RecyclerView.ViewHolder {

        private ImageView img;
        private TextView nomm;
        private ImageView imag;
        private TextView rate;

        public PuppyViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img_pet);
            nomm = itemView.findViewById(R.id.nom_perf);
            imag = itemView.findViewById(R.id.imv_puppy_2);
            rate = itemView.findViewById(R.id.rates);

        }
    }
}

