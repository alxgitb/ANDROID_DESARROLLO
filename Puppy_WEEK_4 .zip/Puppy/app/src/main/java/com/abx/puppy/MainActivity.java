package com.abx.puppy;


import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;


import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

   // private Toolbar toolb;
    static TabLayout tabl;
    private ViewPager vp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


      //  toolb   = (Toolbar)   findViewById(R.id.toolbar);
        tabl    = (TabLayout) findViewById(R.id.tablayout);

        vp      = (ViewPager) findViewById(R.id.viewPager);
        setUpViewPager();
        initBar();


       // if (toolb !=null){
       //     setSupportActionBar(toolb);
       // }

    }

    private ArrayList<Fragment> addFrag(){
        ArrayList<Fragment> fg = new ArrayList<>();
        fg.add(new ListaFragment());
        fg.add(new PuppyFragment());
        return fg;
    }

        private void setUpViewPager(){
         vp.setAdapter(new PageAdapter(getSupportFragmentManager(),addFrag()));
         tabl.setupWithViewPager(vp);
         tabl.getTabAt(0).setIcon(R.mipmap.casa);
         tabl.getTabAt(1).setIcon(R.mipmap.pet);
            View root = tabl.getChildAt(0);
            if (root instanceof LinearLayout) {
                ((LinearLayout) root).setShowDividers(LinearLayout.SHOW_DIVIDER_MIDDLE);
                GradientDrawable drawable = new GradientDrawable();
                drawable.setColor(getResources().getColor(R.color.colorPrimaryDark));
                drawable.setSize(2, 1);
                ((LinearLayout) root).setDividerPadding(10);
                ((LinearLayout) root).setDividerDrawable(drawable);
            }

        }


    public void initBar() {
        Toolbar myToolbar = findViewById(R.id.appbar);
        myToolbar.setLogo(R.drawable.icons8_cat_footprint_24);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.items_actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.five_liked: {
                Intent i = new Intent(this, PuppyList.class);
                //  i.putExtra("top", true);
                startActivityForResult(i, 1);
                return true;
            }

            case R.id.menu_con: {
                Intent i_c = new Intent(this, Contacto.class);
                // i.putExtra("top", true);
                startActivityForResult(i_c, 1);
                return true;
            }

            case R.id.menu_acer: {
                Intent i_a = new Intent(this, Acerca.class);
                // i.putExtra("top", true);
                startActivityForResult(i_a, 1);
                return true;
            }

            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
