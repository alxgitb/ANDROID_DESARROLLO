package com.abx.puppy;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class ListaFragment extends Fragment {

    static ArrayList<Puppy> list;
    private RecyclerView lp;

    public ListaFragment(){

    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);

        View v = inflater.inflate(R.layout.fragment_lista, container, false);
        FloatingActionButton fab = v.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Take a Picture To Your Pet!", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        lp = (RecyclerView) v.findViewById(R.id.recyclerv);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        lp.setLayoutManager(llm);
        inicLista();
        return v;

    }

      public void inicLista() {
        list = new ArrayList<Puppy>();
        list.add(new Puppy("MASCOTA1", R.drawable.p1,0));
        list.add(new Puppy("MASCOTA2", R.drawable.p2,0));
        list.add(new Puppy("MASCOTA3", R.drawable.p3,0));
        list.add(new Puppy("MASCOTA4", R.drawable.p4,0));
        list.add(new Puppy("MASCOTA5", R.drawable.p5,0));
        list.add(new Puppy("MASCOTA6", R.drawable.p6,0));
        list.add(new Puppy("MASCOTA7", R.drawable.p7,0));
        list.add(new Puppy("MASCOTA8", R.drawable.p8,0));
        list.add(new Puppy("MASCOTA9", R.drawable.p9,0));
        inicAdaptador(list);
    }


    public void inicAdaptador(ArrayList<Puppy> l) {
        PuppyAdapter adaptador = new PuppyAdapter(l);
        lp.setAdapter(adaptador);
    }

}
