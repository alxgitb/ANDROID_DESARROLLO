package com.abx.puppy;


import android.support.annotation.NonNull;

public class Puppy {

    private String nom;
    private int foto;
    private int rate;
    public static final int TYPE_ONE = 0;
    public static final int TYPE_TWO = 1;
    public static final int TYPE_THREE = 2;
    private int type;


    public Puppy() {

    }

    public Puppy(String nom, int foto, int type) {
        this.nom = nom;
        this.foto = foto;
        this.rate=0;
        this.type=type;
    }

    public Puppy(String nom, int foto,int type , int rate) {
        this.nom = nom;
        this.foto = foto;
        this.type=type;
        this.rate = rate;
    }

    public int getType(){return type;}

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }


}

