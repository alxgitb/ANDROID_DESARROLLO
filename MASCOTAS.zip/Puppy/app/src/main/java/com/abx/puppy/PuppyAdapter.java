package com.abx.puppy;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class PuppyAdapter extends RecyclerView.Adapter<PuppyAdapter.PuppyViewHolder> {

    ArrayList<Puppy> mascotas;



    PuppyAdapter(ArrayList<Puppy> p){
        this.mascotas = p;

    }
    @NonNull
    @Override //Crea las Lista de Elementos, se asocia al RecyclerView
              //Infla el layout y lo pasara al viewholder para que el obtenga los views
    public PuppyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview,parent, false);
            return new PuppyViewHolder(v);
    }

    @Override //Se envía las list de elementos, a cada elemento del constructor del ViewHolder declarado abajo, se setean las variables.
              //Asocia cada elemento de la list con cada view
    public void onBindViewHolder(@NonNull final PuppyViewHolder holder, final int position) {
        final Puppy masc = mascotas.get(position);
        holder.img.setImageResource(masc.getFoto());
        holder.nomm.setText(masc.getNom());
        refrescarRate(holder, masc);
        holder.btnlike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int like=masc.getRate();
                masc.setRate(++like);
               // MainActivity.list.get(position).setRate(like);
                refrescarRate(holder, masc);
            }

        });
     }

    private void refrescarRate(PuppyViewHolder holder, Puppy masc) {
        holder.rate.setText(((Object)(masc.getRate())).toString());
    }

    @Override //Cantidad de elementos de la Lista
    public int getItemCount() {
        return mascotas.size();
    }

    public static class PuppyViewHolder extends RecyclerView.ViewHolder {

        private ImageView img;
        private TextView nomm;
        private TextView rate;
        private ImageButton btnlike;

        public PuppyViewHolder(View itemView){
             super(itemView);
             img        = itemView.findViewById(R.id.imv_puppy);
             nomm       = itemView.findViewById(R.id.nomp);
             rate       = itemView.findViewById(R.id.rating);
             btnlike    = itemView.findViewById(R.id.btnlike);


        }

    }


}
