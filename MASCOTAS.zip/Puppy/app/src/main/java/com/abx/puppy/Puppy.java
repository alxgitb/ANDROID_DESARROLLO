package com.abx.puppy;


import android.support.annotation.NonNull;

public class Puppy {

    private String nom;
    private int foto;
    private int rate;

    public Puppy() {

    }

    public Puppy(String nom, int foto) {
        this.nom = nom;
        this.foto = foto;
        this.rate=0;
    }

    public Puppy(String nom, int foto, int rate) {
        this.nom = nom;
        this.foto = foto;
        this.rate = rate;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }


}

